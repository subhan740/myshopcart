from twilio.rest import Client


def send_sms(mobile,order):
 
    account_sid = "AC74b0846c1ab7c9d307523d61b27796c7"            #company details
    auth_token = "029bdb173395b26aea61ecec40adf3bb"
    client = Client(account_sid, auth_token)
    user_mobile = mobile
    message = client.messages.create(
        to="+91"+user_mobile,
        #to="+917701839980",
        from_="+12016361376", #Subhan Khan

        # from_="+18555728559",
        # from_="+17042702788", #--office
        body=" Your Order has been Placed.. Track Your Order in MyShoCart App. your Order No is: "+str(order))


